
@echo off

del /S /Q *.o >nul 2>nul
del /S /Q *.d >nul 2>nul
del /Q firmware >nul 2>nul
del /Q *.bin >nul 2>nul

:: You may need to edit/change these three paths to suit your setup
::
:: Temporarily add the compiler and make program directories to the system PATH ..
::
@set PATH="C:\Program Files (x86)\GNU Arm Embedded Toolchain\10 2021.10\bin";%PATH%
@set PATH="C:\Program Files (x86)\GNU Arm Embedded Toolchain\10 2021.10\arm-none-eabi\bin";%PATH%
@set PATH="C:\GnuWin32\bin\";%PATH%

:: Do the compile
::
make clean
make

:: Delete the spent files
::
del /S /Q *.o >nul 2>nul
del /S /Q *.d >nul 2>nul
del /Q firmware >nul 2>nul

:: One of these two lines simply install the required python module if you want to create the packed
:: firmware bin file, either only needs running once, ever.
::
::python  -m pip install --upgrade pip crcmod
::python3 -m pip install --upgrade pip crcmod

:: show the compiled .bin file size
::
::arm-none-eabi-size firmware

pause
@echo on